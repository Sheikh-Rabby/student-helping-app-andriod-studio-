package com.example.signup.inter;

import android.content.DialogInterface;

public interface onDialogCloseListner {
    void  onDialogClose(DialogInterface dialogInterface);

}
